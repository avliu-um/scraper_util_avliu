from src.scraper_util_avliu import example
from src.scraper_util_avliu import util

example.test()

