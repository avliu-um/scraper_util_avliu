# Scraper Util

Utility functions for my web-scraping projects (EV Sales, Asian Yelp, NBA Midlights).

These functions are published as a library on the Python Package Index [here](https://pypi.org/project/scraper-util-avliu/).
