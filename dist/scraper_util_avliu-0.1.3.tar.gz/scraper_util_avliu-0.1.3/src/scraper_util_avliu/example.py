def test():
    print('hello world')